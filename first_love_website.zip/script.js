document.getElementById('guestbook-form').addEventListener('submit', function(event) {
    event.preventDefault();
    const name = document.getElementById('name').value;
    const message = document.getElementById('message').value;
    const li = document.createElement('li');
    li.textContent = `${name}: ${message}`;
    document.getElementById('messages').appendChild(li);
    document.getElementById('guestbook-form').reset();
});
